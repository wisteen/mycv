from django.apps import AppConfig


class ShareafricAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shareafric_app'
